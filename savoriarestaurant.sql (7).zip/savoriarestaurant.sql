-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 05, 2025 at 09:18 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `savoriarestaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `ban`
--

CREATE TABLE `ban` (
  `idban` int(11) NOT NULL auto_increment,
  `soghe` int(11) NOT NULL,
  `vitri` varchar(110) collate utf8_unicode_ci default NULL,
  `trangthai` int(11) NOT NULL,
  `id_user` int(11) default NULL,
  `tenkh` varchar(200) collate utf8_unicode_ci default NULL,
  `ngaydatban` datetime default NULL,
  `sdt` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`idban`),
  KEY `fk_ban_nguoidung` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `ban`
--

INSERT INTO `ban` (`idban`, `soghe`, `vitri`, `trangthai`, `id_user`, `tenkh`, `ngaydatban`, `sdt`) VALUES
(1, 4, '1', 1, 2, NULL, NULL, NULL),
(2, 6, '1', 1, NULL, 'kiệt', '2025-05-02 18:13:00', '123123123'),
(3, 8, '2', 0, NULL, NULL, NULL, NULL),
(4, 4, '1', 0, NULL, NULL, NULL, NULL),
(5, 6, '4', 0, NULL, NULL, NULL, NULL),
(6, 8, '2', 0, NULL, NULL, NULL, NULL),
(7, 4, '4', 0, NULL, NULL, NULL, NULL),
(8, 6, '1', 0, NULL, NULL, NULL, NULL),
(9, 8, '3', 0, NULL, NULL, NULL, NULL),
(10, 4, '3', 0, NULL, NULL, NULL, NULL),
(11, 6, '1', 0, NULL, NULL, NULL, NULL),
(12, 8, '4', 0, NULL, NULL, NULL, NULL),
(13, 4, '4', 0, NULL, NULL, NULL, NULL),
(14, 6, '4', 0, NULL, NULL, NULL, NULL),
(15, 8, '3', 0, NULL, NULL, NULL, NULL),
(16, 4, '3', 0, NULL, NULL, NULL, NULL),
(17, 6, '2', 0, NULL, NULL, NULL, NULL),
(18, 8, '2', 0, NULL, NULL, NULL, NULL),
(19, 4, '2', 0, NULL, NULL, NULL, NULL),
(20, 6, '3', 1, 2, NULL, '2025-05-17 16:32:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chatbox`
--

CREATE TABLE `chatbox` (
  `id_chat` int(11) NOT NULL auto_increment,
  `cauhoi` varchar(1000) collate utf8_unicode_ci NOT NULL,
  `cautraloi` varchar(1000) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_chat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `chatbox`
--


-- --------------------------------------------------------

--
-- Table structure for table `chitiethoadon`
--

CREATE TABLE `chitiethoadon` (
  `id_chitiethd` int(11) NOT NULL auto_increment,
  `idmonan` int(11) NOT NULL,
  `tenmonan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `dongia` float NOT NULL,
  `soluong` int(11) NOT NULL,
  `giamgia` float NOT NULL,
  `id_hd` int(11) NOT NULL,
  PRIMARY KEY  (`id_chitiethd`),
  KEY `fk_chitiethoadon_hoadon` (`id_hd`),
  KEY `fk_chitiethoadon_monan` (`idmonan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `chitiethoadon`
--


-- --------------------------------------------------------

--
-- Table structure for table `dondatban`
--

CREATE TABLE `dondatban` (
  `idddb` int(11) NOT NULL auto_increment,
  `tenkh` varchar(200) collate utf8_unicode_ci default NULL,
  `ngaydatban` datetime default NULL,
  `sdt` varchar(20) collate utf8_unicode_ci default NULL,
  `id_user` int(11) default NULL,
  `email` varchar(100) collate utf8_unicode_ci default NULL,
  `ghichu` varchar(1000) collate utf8_unicode_ci default NULL,
  `soluong` int(11) NOT NULL,
  PRIMARY KEY  (`idddb`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `dondatban`
--

INSERT INTO `dondatban` (`idddb`, `tenkh`, `ngaydatban`, `sdt`, `id_user`, `email`, `ghichu`, `soluong`) VALUES
(1, 'Trần Cao Kiệt', '2025-05-05 22:05:00', '0364127297', NULL, 'abc@gmail.com', '123123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `giohang`
--

CREATE TABLE `giohang` (
  `id_giohang` int(11) NOT NULL auto_increment,
  `idmonan` int(11) NOT NULL,
  `tenmonan` varchar(100) collate utf8_unicode_ci NOT NULL,
  `dongia` float NOT NULL,
  `soluong` int(11) NOT NULL,
  `trangthai` int(11) NOT NULL,
  PRIMARY KEY  (`id_giohang`),
  KEY `fk_giohang_monan` (`idmonan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `giohang`
--


-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE `hoadon` (
  `id_hd` int(11) NOT NULL auto_increment,
  `idmonan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ngaylayhd` date NOT NULL,
  PRIMARY KEY  (`id_hd`),
  KEY `fk_hoadon_monan` (`idmonan`),
  KEY `fk_hoadon_nguoidung` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hoadon`
--


-- --------------------------------------------------------

--
-- Table structure for table `loaimonan`
--

CREATE TABLE `loaimonan` (
  `idloaimon` int(11) NOT NULL,
  `tenloai` varchar(50) collate utf8_unicode_ci NOT NULL,
  `field` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`idloaimon`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loaimonan`
--

INSERT INTO `loaimonan` (`idloaimon`, `tenloai`, `field`) VALUES
(1, 'Khai vị', 'starter'),
(2, 'Món chính', 'main'),
(3, 'Tráng miệng', 'dessert'),
(4, 'Đồ uống', 'drink'),
(5, 'Ăn nhẹ', 'snack');

-- --------------------------------------------------------

--
-- Table structure for table `monan`
--

CREATE TABLE `monan` (
  `idmonan` int(11) NOT NULL auto_increment,
  `tenmonan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `mota` varchar(500) collate utf8_unicode_ci default NULL,
  `giaban` float default NULL,
  `hinhanh` varchar(20) collate utf8_unicode_ci default NULL,
  `trangthai` int(11) NOT NULL,
  `idloaimonan` int(11) NOT NULL,
  PRIMARY KEY  (`idmonan`),
  KEY `fk_monan_loaimonan` (`idloaimonan`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `monan`
--

INSERT INTO `monan` (`idmonan`, `tenmonan`, `mota`, `giaban`, `hinhanh`, `trangthai`, `idloaimonan`) VALUES
(1, 'Gỏi cuốn tây sơn', 'Gỏi cuốn tôm thịt ăn kèm nước chấm chua ngọt.', 25000, 'goicuon.jpg', 1, 1),
(2, 'Súp cua', 'Súp cua nóng hổi, giàu dinh dưỡng.', 30000, 'supcua.jpg', 1, 1),
(3, 'Cơm gà xối mỡ', 'Gà giòn rụm, cơm thơm béo, kèm nước mắm chua ngọt.', 45000, 'comga.jpg', 1, 2),
(4, 'Phở bò', 'Phở bò truyền thống với nước dùng đậm đà.', 40000, 'phobo.jpg', 1, 2),
(5, 'Chè ba màu', 'Chè truyền thống mát lạnh, ngọt dịu.', 20000, 'chebamau.jpg', 1, 3),
(6, 'Bánh flan', 'Bánh flan mềm mịn, dùng kèm cà phê sữa.', 18000, 'flan.jpg', 1, 3),
(7, 'Trà đào', 'Trà đào mát lạnh, topping miếng đào giòn.', 25000, 'tradao.jpg', 1, 4),
(8, 'Sinh tố bơ', 'Sinh tố bơ nguyên chất, béo ngậy.', 30000, 'botto.jpg', 1, 4),
(9, 'Khoai tây chiên', 'Khoai tây chiên giòn rụm, ăn kèm tương ớt.', 20000, 'khoaitay.jpg', 1, 5),
(10, 'Bánh mì que', 'Bánh mì giòn với nhân pate cay.', 15000, 'banhmique.jpg', 1, 5),
(11, 'Burger nhỏ', 'burger nhỏ', 40000, '666_P-BURGER.jpg', 1, 2),
(12, 'Beefsteek', 'bò Mỹ chất lương cao', 350000, '552_P-RICE-KING.png', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `nguoidung`
--

CREATE TABLE `nguoidung` (
  `id_user` int(11) NOT NULL auto_increment,
  `hoten` varchar(50) collate utf8_unicode_ci NOT NULL,
  `gioitinh` int(11) NOT NULL,
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  `sdt` varchar(15) collate utf8_unicode_ci NOT NULL,
  `id_role` int(11) NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `trangthai` int(11) NOT NULL,
  PRIMARY KEY  (`id_user`),
  KEY `fk_id_role` (`id_role`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `nguoidung`
--

INSERT INTO `nguoidung` (`id_user`, `hoten`, `gioitinh`, `email`, `sdt`, `id_role`, `password`, `trangthai`) VALUES
(1, 'Nguyễn Văn An', 1, 'nguyenvanan@gmail.com', '0912345678', 1, 'e10adc3949ba59abbe56e057f20f883e', 1),
(2, 'trancaokiet', 1, 'trancaokiet@gmail.com', '0123456789', 4, 'e10adc3949ba59abbe56e057f20f883e', 1),
(3, 'quynh huong', 0, 'huong123@gmail.com', '0986345724', 2, 'e10adc3949ba59abbe56e057f20f883e', 1),
(4, 'Nguyễn Minh', 1, 'minh123@gmail.com', '0324685468', 3, 'e10adc3949ba59abbe56e057f20f883e', 1),
(5, 'admin', 1, 'admin@admin.com', '0123456789', 1, '21232f297a57a5a743894a0e4a801fc3', 1),
(6, 'Trần Văn Ân', 1, 'an@gmail.com', '0123456789', 1, '123456', 1),
(14, 'kiệt trần', 1, 'abc@gmail.com', '0364127297', 4, 'e10adc3949ba59abbe56e057f20f883e', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vaitro`
--

CREATE TABLE `vaitro` (
  `id_role` int(11) NOT NULL auto_increment,
  `tenvaitro` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_role`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `vaitro`
--

INSERT INTO `vaitro` (`id_role`, `tenvaitro`) VALUES
(1, 'Quản trị viên'),
(2, 'Quản lý'),
(3, 'Nhân viên'),
(4, 'Khách hàng');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ban`
--
ALTER TABLE `ban`
  ADD CONSTRAINT `fk_ban_nguoidung` FOREIGN KEY (`id_user`) REFERENCES `nguoidung` (`id_user`);

--
-- Constraints for table `chitiethoadon`
--
ALTER TABLE `chitiethoadon`
  ADD CONSTRAINT `fk_chitiethoadon_hoadon` FOREIGN KEY (`id_hd`) REFERENCES `hoadon` (`id_hd`),
  ADD CONSTRAINT `fk_chitiethoadon_monan` FOREIGN KEY (`idmonan`) REFERENCES `monan` (`idmonan`);

--
-- Constraints for table `giohang`
--
ALTER TABLE `giohang`
  ADD CONSTRAINT `fk_giohang_monan` FOREIGN KEY (`idmonan`) REFERENCES `monan` (`idmonan`);

--
-- Constraints for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD CONSTRAINT `fk_hoadon_monan` FOREIGN KEY (`idmonan`) REFERENCES `monan` (`idmonan`),
  ADD CONSTRAINT `fk_hoadon_nguoidung` FOREIGN KEY (`id_user`) REFERENCES `nguoidung` (`id_user`);

--
-- Constraints for table `monan`
--
ALTER TABLE `monan`
  ADD CONSTRAINT `fk_monan_loaimonan` FOREIGN KEY (`idloaimonan`) REFERENCES `loaimonan` (`idloaimon`);

--
-- Constraints for table `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD CONSTRAINT `fk_id_role` FOREIGN KEY (`id_role`) REFERENCES `vaitro` (`id_role`);
